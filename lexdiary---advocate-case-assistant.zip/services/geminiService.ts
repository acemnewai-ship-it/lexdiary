
import { GoogleGenAI } from "@google/genai";
import { Case } from "../types";

// Initialize AI and generate a summary of the daily cause list
export const summarizeDailyCauseList = async (cases: Case[]) => {
  if (cases.length === 0) return "No hearings scheduled for today.";
  
  // Create a new GoogleGenAI instance right before making an API call to ensure it always uses the most up-to-date API key.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const caseData = cases.map(c => 
    `${c.caseNo} (${c.caseType}): ${c.appellant} vs ${c.respondent}. Purpose: ${c.reasonOfHearing}`
  ).join('\n');

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Please provide a professional, concise summary of the following legal cause list for an advocate's morning briefing. Highlight urgent matters based on the purpose of hearing.
    
    Cause List:
    ${caseData}`,
    config: {
      systemInstruction: "You are a highly efficient legal clerk assisting a senior advocate. Be brief, professional, and focus on tactical advice for the day.",
    }
  });

  return response.text || "Unable to generate summary at this time.";
};

// Initialize AI and handle chat queries with case context
export const chatWithLegalAI = async (query: string, contextCases: Case[]) => {
  // Use a new instance for each call as per SDK recommendations
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const caseContext = contextCases.map(c => `${c.caseNo}: ${c.appellant} vs ${c.respondent}`).join(', ');
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `User Query: ${query}`,
    config: {
      systemInstruction: `You are LexAI, a professional legal assistant for advocates. 
      You have access to the following current cases in the user's diary: ${caseContext}. 
      Help the user with research, drafting ideas, or organization. 
      Always maintain high professional standards. Do not give binding legal advice; suggest strategies instead.`,
    }
  });

  return response.text || "I'm sorry, I couldn't process that request right now.";
};
