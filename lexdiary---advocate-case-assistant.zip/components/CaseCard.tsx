
import React from 'react';
import { Calendar, User, UserCheck, Tag, Info, CheckCircle2, Trash2, Gavel } from 'lucide-react';
import { Case, CaseStatus } from '../types';

interface CaseCardProps {
  caseData: Case;
  onDispose?: (id: string) => void;
  onDelete?: (id: string) => void;
  readOnly?: boolean;
}

const CaseCard: React.FC<CaseCardProps> = ({ caseData, onDispose, onDelete, readOnly = false }) => {
  const isDisposed = caseData.status === CaseStatus.DISPOSED;

  return (
    <div className={`bg-white rounded-xl shadow-sm border ${isDisposed ? 'border-green-100 bg-green-50/20' : 'border-slate-200'} p-4 transition-all hover:shadow-md`}>
      <div className="flex justify-between items-start mb-3">
        <div className="flex flex-col">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            {caseData.caseType} • {caseData.caseNo}
          </span>
          <h3 className="text-lg font-bold text-slate-800 leading-tight">
            {caseData.appellant} <span className="text-slate-400 font-normal">vs</span> {caseData.respondent}
          </h3>
        </div>
        <div className={`px-2 py-1 rounded text-[10px] font-bold ${isDisposed ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>
          {caseData.status}
        </div>
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex items-center gap-2 text-sm text-slate-600">
          <Gavel className="w-4 h-4 text-slate-400" />
          <span>Court: <span className="font-semibold text-slate-800">{caseData.courtName}</span></span>
        </div>
        <div className="flex items-center gap-2 text-sm text-slate-600">
          <Info className="w-4 h-4 text-slate-400" />
          <span>Purpose: <span className="font-semibold text-slate-800">{caseData.reasonOfHearing}</span></span>
        </div>
        <div className="flex items-center gap-2 text-sm text-slate-600">
          <Calendar className="w-4 h-4 text-slate-400" />
          <span>Hearing: <span className="font-semibold text-slate-800">{new Date(caseData.nextHearingDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span></span>
        </div>
      </div>

      {!readOnly && (
        <div className="flex items-center gap-2 mt-4 pt-4 border-t border-slate-100">
          {!isDisposed && onDispose && (
            <button 
              onClick={() => onDispose(caseData.id)}
              className="flex-1 flex items-center justify-center gap-2 bg-indigo-50 text-indigo-700 py-2 rounded-lg text-xs font-semibold hover:bg-indigo-100 transition-colors"
            >
              <CheckCircle2 className="w-4 h-4" />
              Mark Disposed
            </button>
          )}
          {onDelete && (
            <button 
              onClick={() => onDelete(caseData.id)}
              className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default CaseCard;
