
import React from 'react';
import { NAV_ITEMS, CLIENT_NAV_ITEMS } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (id: string) => void;
  role?: string;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange, role = 'ADVOCATE' }) => {
  const items = role === 'ADVOCATE' ? NAV_ITEMS : CLIENT_NAV_ITEMS;

  return (
    <div className="flex flex-col min-h-screen pb-20 md:pb-0 md:pt-16">
      {/* Top Header for Desktop/Tablet */}
      <header className="fixed top-0 left-0 right-0 bg-white border-b border-slate-200 z-50 h-16 hidden md:flex items-center px-6 justify-between shadow-sm">
        <div className="flex items-center gap-2">
          <div className={`w-8 h-8 ${role === 'ADVOCATE' ? 'bg-indigo-600' : 'bg-emerald-600'} rounded flex items-center justify-center text-white font-bold`}>L</div>
          <h1 className="text-xl font-bold text-slate-800 tracking-tight">LexDiary</h1>
        </div>
        <nav className="flex items-center gap-6">
          {items.map(item => (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`text-sm font-medium transition-colors ${
                activeTab === item.id ? (role === 'ADVOCATE' ? 'text-indigo-600' : 'text-emerald-600') : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>
      </header>

      {/* Mobile Header */}
      <header className={`fixed top-0 left-0 right-0 ${role === 'ADVOCATE' ? 'bg-indigo-600' : 'bg-emerald-600'} text-white p-4 md:hidden z-50 flex justify-between items-center shadow-md`}>
        <h1 className="text-lg font-bold uppercase tracking-widest">LexDiary</h1>
        <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
          <span className="text-xs font-bold uppercase">{role === 'ADVOCATE' ? 'AD' : 'CL'}</span>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 mt-16 md:mt-0 p-4 md:p-8 max-w-5xl mx-auto w-full">
        {children}
      </main>

      {/* Bottom Navigation for Mobile */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 md:hidden z-50 flex justify-around items-center h-16 px-2 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        {items.map(item => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`flex flex-col items-center justify-center gap-1 transition-all ${
              activeTab === item.id ? (role === 'ADVOCATE' ? 'text-indigo-600' : 'text-emerald-600') : 'text-slate-400'
            }`}
          >
            {item.icon}
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

export default Layout;
