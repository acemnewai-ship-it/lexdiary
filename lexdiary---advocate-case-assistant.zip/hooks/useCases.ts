
import { useState, useEffect } from 'react';
import { Case, CaseStatus } from '../types';

export const useCases = () => {
  const [cases, setCases] = useState<Case[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('lexdiary_cases');
    if (saved) {
      setCases(JSON.parse(saved));
    }
  }, []);

  const saveCases = (newCases: Case[]) => {
    setCases(newCases);
    localStorage.setItem('lexdiary_cases', JSON.stringify(newCases));
  };

  const addCase = (newCase: Omit<Case, 'id' | 'createdAt'>) => {
    const caseWithId: Case = {
      ...newCase,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
    };
    saveCases([caseWithId, ...cases]);
  };

  const updateCase = (updatedCase: Case) => {
    const updated = cases.map(c => c.id === updatedCase.id ? updatedCase : c);
    saveCases(updated);
  };

  const deleteCase = (id: string) => {
    saveCases(cases.filter(c => c.id !== id));
  };

  const disposeCase = (id: string) => {
    const updated = cases.map(c => {
      if (c.id === id) {
        return {
          ...c,
          status: CaseStatus.DISPOSED,
          disposalDate: new Date().toISOString()
        };
      }
      return c;
    });
    saveCases(updated);
  };

  const exportCauseListForDate = (date: string) => {
    const dailyCases = cases.filter(c => c.nextHearingDate === date && c.status === CaseStatus.ACTIVE);
    if (dailyCases.length === 0) return;

    const headers = ['Court', 'Case No', 'Type', 'Appellant', 'Respondent', 'Purpose'];
    const rows = dailyCases.map(c => [
      c.courtName,
      c.caseNo,
      c.caseType,
      c.appellant,
      c.respondent,
      c.reasonOfHearing
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `CauseList_${date}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportToCSV = () => {
    if (cases.length === 0) return;
    const headers = ['Court', 'Case Type', 'Case No', 'Appellant', 'Respondent', 'Hearing Reason', 'Next Date', 'Status'];
    const rows = cases.map(c => [
      c.courtName,
      c.caseType,
      c.caseNo,
      c.appellant,
      c.respondent,
      c.reasonOfHearing,
      new Date(c.nextHearingDate).toLocaleDateString(),
      c.status
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `CaseDiary_FullExport_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return { cases, addCase, updateCase, deleteCase, disposeCase, exportToCSV, exportCauseListForDate };
};
